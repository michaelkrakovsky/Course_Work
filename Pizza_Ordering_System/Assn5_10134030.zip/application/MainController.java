//The following code is a GUI of the pizza order system
//The code was written by Michael Krakovsky.

package application;

import java.net.URL;
import java.util.ResourceBundle;
import PizzaOrderSystem.*;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;

public class MainController implements Initializable{
    
	@FXML
	private ComboBox<String> sizeBox;               //Four combo boxes that store the topic options
	@FXML
	private ComboBox<String> cheeseBox;
	@FXML
	private ComboBox<String> mushroomsBox;
	@FXML
	private ComboBox<String> pepperoniBox;
	@FXML
	private Label indicator;
	@FXML
	private Label currentCost;
	@FXML
	private Label lineItemIndicator;           //indicates the lineItem
	@FXML
	private TextArea customersLine;    //stores the lineItems within a combo box
	@FXML
	private TextField numberOfPizzas;
	@FXML
	private Button confirmOrder;						//Used to confirm order
	@FXML
	private Button seeCostOfLineItem;
	@FXML
	private Button submitOrder;						//Used to end order
	@FXML											//Four lists that indicate the topic options
	ObservableList<String> sizeList = FXCollections.observableArrayList("Small", "Medium", "Large");
	@FXML
	ObservableList<String> cheeseAmountList = FXCollections.observableArrayList("Single", "Double", "Triple");
	@FXML
	ObservableList<String> mushroomsAmountList = FXCollections.observableArrayList("Single", "Double", "None");
	@FXML
	ObservableList<String> pepperoniAmountList = FXCollections.observableArrayList("Single", "Double", "None");
	int storeTotalcost = 0;       //The final cost of the lineItem

	public void initialize(URL arg0, ResourceBundle arg1) {        //A method that initializes the first for combo boxes

		sizeBox.setItems(sizeList);
		cheeseBox.setItems(cheeseAmountList);
		mushroomsBox.setItems(mushroomsAmountList);
		pepperoniBox.setItems(pepperoniAmountList);
	}
	
	private Pizza createAPizza () {      //If the user attempts to create a pizza, try but worn of potential error related to the pizza
		
		try {
			Pizza createNewPizza = new Pizza(sizeBox.getValue(), cheeseBox.getValue() , mushroomsBox.getValue(), pepperoniBox.getValue());
			indicator.setText("$" + String.valueOf(createNewPizza.getCost()) + "0");
			return createNewPizza;
		} catch (IllegalPizza e) {
			if ((sizeBox.getValue() == null) || (cheeseBox.getValue() == null) || (mushroomsBox.getValue() == null) || (pepperoniBox.getValue() == null)){
				indicator.setText("No items.");
				lineItemIndicator.setText("Please fill all the selection boxes.");
			} else if ((pepperoniBox.getValue().toLowerCase().equals("none")) && (mushroomsBox.getValue().toLowerCase().equals("none") == false))  {
				lineItemIndicator.setText("You cannot have mushrooms without pepperoni.");
			}
	    }
		return null;
	}
	
	private int checkUserInput () {       //ensure the user input is legal
		
		String userInput = numberOfPizzas.getText();
		int userNumber;
		
		try {
			userNumber = Integer.parseInt(userInput);
			if((userNumber > 0) && (userNumber < 101)) {
			    return userNumber;
			} else {
				lineItemIndicator.setText("Please enter a number between 1 - 100.");
			}
		} catch (NumberFormatException e) {
			lineItemIndicator.setText("Please enter a number between 1 - 100.");
		}
		return 0;
	}
	
	public void getCostButton(ActionEvent event) {     //Button that gets costs for item
		
		createAPizza();
	}
	
	private LineItem createLineItem(Pizza aPizza, int aNumber) {    //create a lineItem and write the item into the box or indicate an error
		
		try {
			if ((aPizza != null) || ((aNumber > 0) && aNumber < 101)) {
		        LineItem order = new LineItem(aNumber, aPizza);
		        lineItemIndicator.setText("The cost is $" + (int)order.getCost() + ".00 for " + order.toString());
		        return order;
			}
		} catch (IllegalPizza e) {
			//errros are displayed in other functions
		}
		return null;      //null indicates the value did not successful 
	}
	
	public void getLineItemCost(ActionEvent event) {       //perform actions all actions once the create button is created 
    
		LineItem finalOrder = createLineItem(createAPizza(), checkUserInput());		
		if (finalOrder != null) {
			storeTotalcost += finalOrder.getCost();
	        currentCost.setText( "The current cost: $" + storeTotalcost + ".00");
			customersLine.appendText(finalOrder.toString() + ".\n");   //display line item with cost
		}
	}
	public void submitFinalOrder(ActionEvent event) {    //Exit the program 
		
		System.exit(0);
	}
}
