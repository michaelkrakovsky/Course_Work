//A class to define all nails

public class CommonNail extends Nail{

	private static final long serialVersionUID = -969489786986044170L;
	
	//new CommonNail("10D", 3.0, 9.0, "Bright", 21.69, 345);
	public CommonNail (String size,  double length, double gauge, String finish, double unitPrice, int numberPerUnit) throws IllegalFastener {
		super(size, length, gauge, finish, unitPrice, numberPerUnit);
		checkFinish(finish);		
	}
	
	//Finishes must be Bright, Hot Dipped Galvanized.
	private void checkFinish (String finish) throws IllegalFastener {
		
		if ((finish.equalsIgnoreCase("Bright") == false) && (finish.equalsIgnoreCase("Hot Dipped Galvanized") == false)) {
			throw new IllegalFastener("Common Nails Must be Bright or Hot Dipped Galvanized.");
		}
	}
	
	public String toString () {
		
		return "Common Nail, " + super.toString();
	}
}
