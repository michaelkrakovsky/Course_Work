package PizzaOrderSystem;

/** An Exception that is thrown when the data is not properly inputed
 * <p>Here are the following exceptions.</p>
 * <ul>
 * <li>size, which can be "small", "medium" or "large", only</li>
 *<li>cheese, which can be "single", "double" or "triple</li>
 *<li>mushrooms, which can be "none", "single" or "double</li>
 *<li>pepperoni, which can be "none", "single" or "double"</li>
 *<li>a Pizza cannot have mushrooms unless it has single or double pepperoni</li>
 */
public class IllegalPizza extends Exception {  
	
	public IllegalPizza(String message) {         //Supplies the illegal message
		super(message);
	}
}
