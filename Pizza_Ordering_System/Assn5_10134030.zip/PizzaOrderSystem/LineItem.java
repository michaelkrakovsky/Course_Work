package PizzaOrderSystem;

import java.io.Serializable;
/**
 * A class to store information about the orders for pizza.
 * <p>
 * It will contain a pointer to the object and will contain the number
 * of those pizzas ordered
 * </p>
 * @author Michael Krakovsky
 *@version 1.0 
 */

public class LineItem implements Comparable<LineItem>, Serializable {
    
	/**
	 * The constructor will contain the pointer to an object and will store how many
	 * of those types of pizzas exist
	 * @param pizzaType The pointer to an object
	 * @param numberOfPizzas The number of the pizzas that much that type
	 */
	
	private static final long serialVersionUID = -8785399128583565326L;
	private Pizza pizzaType;
	private int numberOfPizzas;
	
	public LineItem (Pizza typeOfPizza) throws IllegalPizza {        //Default to one if only pizza object is inputed
		setPizzaType(typeOfPizza);
		numberOfPizzas = 1;   
	}
	
	public LineItem (int numberOfPizzas, Pizza pizzaType) throws IllegalPizza {  //Main constructor of two parameters
		setPizzaType(pizzaType);
		setNumber(numberOfPizzas);
	}
	/**
	 * Ensure that the pizza object entered is not null, and type pizza
	 * @param typeOfPizza This will validate the objected entered
	 * @throws IllegalPizza An exception is thrown when the number of pizzas does not equal 1 to 100 inclusive
	 */
	private void setPizzaType (Pizza typeOfPizza) throws IllegalPizza {
		if ((typeOfPizza instanceof Pizza) && (typeOfPizza != null)) {
			pizzaType = typeOfPizza;
		} else {
			throw new IllegalPizza("You cannot enter a null value for the pizza object.");
		}
	}
	/**
	 * Sets the number of pizzas within the type. (Mutable)
	 * @param pizzaNumber The number of the pizzas that much that type.
	 * @throws IllegalPizza
	 */
	public void setNumber (int pizzaNumber) throws IllegalPizza {
		
		if ((pizzaNumber >= 1) && (pizzaNumber <= 100)) {
			numberOfPizzas = pizzaNumber;
		} else {
			throw new IllegalPizza("The pizza number does not lie between 1 to 100 inclusive.");
		}
	}
	/**
	 * Acts has an accessor for the Object pizzaType
	 * @return pizzaType to the user 
	 */
	public Pizza getPizza () {
		
		return pizzaType;
	}
	/**
	 * Acts has an accessor for the Int numberOfPizzas
	 * @return numberOfPizzas to the user 
	 */
	public int getNumber () {
		
		return numberOfPizzas;
	}
	/**
	 * An accessor that returns the cost of the pizza. The line item cost 
	 * is subject to a "bulk discount" - 10 to 20 pizzas, inclusive, gets 
	 * a 10% discount and an order of more than 20 gets a 15% discount.
	 * @param pizzaNumber is the number of pizzas within the order
	 * @return totalCost which is the cost of the pizza
	 */
	public double getCost () {
		
		double totalCost = (pizzaType.getCost() * numberOfPizzas);
		
		if ((numberOfPizzas >= 10) && (numberOfPizzas <= 20)) {
			return (totalCost * 0.9);    //discount the pizza by 10% 
		} else if (numberOfPizzas > 20) {
			return (totalCost * 0.85);    //discount the pizza by 20%
		} else {
			return totalCost;
		}
	}
    /**
     * Method that returns a description of the line item
     * @return A String that represents the contents of the object
     */
	//Overrides the current toString method of the Object class
	@Override
	public String toString () {
		
		return (numberOfPizzas + " " + pizzaType.toString());
	}
	/**
	 * The method will list the highest total cost line items first 
	 * followed by the lower total cost line items.
	 * @param The line item you wish to have compared
	 * @return This method should return the difference of the line items.
	 * It will return zero if the cost difference is less than one dollar.
	 */
	@Override
	public int compareTo (LineItem objectCost) {
		
		return (int)(objectCost.getCost() - getCost());	
	}
}
