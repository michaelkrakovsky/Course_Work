
public abstract class Nail extends Fastener{
	
	private static final long serialVersionUID = -969489786986044170L;
	private String size;
	private double length;
	private double gauge;
	
	//new CommonNail("10D", 3.0, 9.0, "Bright", 21.69, 345);
	public Nail (String size,  double length, double gauge, String finish, double unitPrice, int numberPerUnit) throws IllegalFastener {
		super(finish, unitPrice, numberPerUnit); 
		setSize(size);
		setLength(length);
		setGauge(gauge);		
	}
	
	//Sizes for Common Nails: 6D, 8D, 10D, 12D, 16D, 60D.
	private void setSize (String size) throws IllegalFastener{
		
		if (size == null) {
			throw new IllegalFastener("Size cannot be entered as null.");
		} else if ((size.equalsIgnoreCase("6D") == true) || (size.equalsIgnoreCase("8D") == true)
				|| (size.equalsIgnoreCase("10D") == true) || (size.equalsIgnoreCase("12D") == true) 
				|| (size.equalsIgnoreCase("16D") == true) || (size.equalsIgnoreCase("60D") == true)) {
			this.size = size;
		} else {
			throw new IllegalFastener("Size contains an incorrect value.");
		}
	}
	
	//Lengths for Common Nails: 2, 2.5, 3, 3.25, 3.5, 6 (in inches).
	private void setLength (double length) throws IllegalFastener{
		
		if ((length == 2) || (length == 2.5) || (length == 3) || (length == 3.25)
		    || (length == 3.5) || (length == 6)) {
			this.length = length;
		} else {
			throw new IllegalFastener("Length contains an incorrect value.");
		}
	}
	
	//Gauge for Common Nails: 2, 8, 9, 10.25, 11.5
	private void setGauge (double gauge) throws IllegalFastener {
		if ((gauge == 2.0) || (gauge == 8.0) || (gauge == 9.0) 
			|| (gauge == 10.25) || (gauge == 11.5)) {
				this.gauge = gauge;
		} else {
			throw new IllegalFastener("Gauge contains an incorrect value.");
		}
	}
	
	public String toString () {
		
		return size + " size, " + length + "\" long, " + gauge + " gauge, " + super.toString();
	}
}


