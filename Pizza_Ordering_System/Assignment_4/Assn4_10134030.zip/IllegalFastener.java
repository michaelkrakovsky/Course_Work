//Used to raise exceptions if the code is not properly inputed

public class IllegalFastener extends Exception {

	private static final long serialVersionUID = 3292889047196973345L;

	public IllegalFastener(String message) {    //allows programmer to throw customizable messages
		super(message);
	}
}


