//Direct child of the fastenal class, represents all threaded fastenals
public abstract class InnerThreaded extends Fastener{
    

	private static final long serialVersionUID = 8525286116068735910L;
	private String thread;
	
	//inherit all attributes from the Fastenal class
	public InnerThreaded (String material, String finish, double unitPrice, int numberPerUnit, String thread) throws IllegalFastener { 
		super(material, finish, unitPrice, numberPerUnit);
		setThread(thread);
	}
	
	private void setThread (String thread) throws IllegalFastener{      //create a private method to set the diameter attribute which must equal 
        																//#8-13, #8-15, #8-32, #10-13, #10-24, #10-32, 1/4"-20, 5/16"-18, 3/8"-16, 7/16"-14, 1/2"-13, 5/8"-11, 3/4"-10.
		if (thread == null) {
			throw new IllegalFastener("Your input for the thread field is not correct.");
		} else if ((thread.equals("#8-13") == true) || (thread.equals("#8-15") == true) || (thread.equals("#8-32") == true) 
				|| (thread.equals("#10-13") == true) || (thread.equals("#10-24") == true) || (thread.equals("#10-32") == true) 
				|| (thread.equals("1/4-20") == true) || (thread.equals("5/16-18") == true) || (thread.equals("3/8-16") == true) 
				|| (thread.equals("7/16-14") == true) || (thread.equals("1/2-13") == true) || (thread.equals("5/8-11") == true) 
				|| (thread.equals("3/4-10") == true)) {
			this.thread = thread;
		} else {
			throw new IllegalFastener("Your input for the thread field is not correct.");   //throw exception if all else fails
		}
	}
	
	public String toString() {
		return thread + " thread, " + super.toString();
	}
}

