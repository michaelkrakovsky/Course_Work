//direct child of length threaded fastenals, includes a new style feature unique to the wire inserts 
public class WireInserts extends Bolt {
	
	private static final long serialVersionUID = 8166538706417957238L;
	private String style;
	
	public WireInserts(String material, String finish, double unitPrice, int numberPerUnit, String thread, double length, String style) throws IllegalFastener {
		super(material, finish, unitPrice, numberPerUnit, thread, length);
		setStyle(style);
		checkFinish(finish);
	}
	
	//style can be self-locking, or free running
	private void setStyle(String style) throws IllegalFastener{
		
		if (style == null) {
			throw new IllegalFastener("The value cannot be null.");
		} else if ((style.equalsIgnoreCase("self-locking") == true) || (style.equalsIgnoreCase("free running") == true)) {
			this.style = style;
		} else {
			throw new IllegalFastener("The style value is incorrect.");
		}
	}
	
	//Only for steel screws: Black Phosphate, ACQ 1000 Hour, Lubricated. Only for nails: Bright
	private void checkFinish (String finish) throws IllegalFastener {
		
		if ((finish.equalsIgnoreCase("Bright") == true) || (finish.equalsIgnoreCase("Black Phosphate") == true)
			|| (finish.equalsIgnoreCase("ACQ 1000 Hour") == true) || (finish.equalsIgnoreCase("Lubricated") == true)) {
				throw new IllegalFastener("Your input for the finish class is incorrect.");
		}
	}
	
	public String toString() {
		return "Wire Insert, " + style + " style, " + super.toString();
	}
}
