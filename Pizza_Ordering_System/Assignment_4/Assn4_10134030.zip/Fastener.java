import java.io.Serializable;

//Parents class of all types. Everything will inherit from the Fastenal class
public abstract class Fastener implements Serializable {    

	private static final long serialVersionUID = -7836055613357768660L; //make serializable to pass hierarchy tests
	private String material;
	private String finish;
	private double unitPrice;
	private int numberPerUnit;
	
	public Fastener (String material, String finish, double unitPrice, int numberPerUnit) throws IllegalFastener {
		
		setMaterial(material);
		setFinishes(finish);
		setNumberPerUnit(numberPerUnit);
		setPricePerUnit(unitPrice);
	}
	
	public Fastener(String finish, double unitPrice, int numberPerUnit) throws IllegalFastener{  //assume nail is desired without inputting the material 
		
		material = "Steel";
		setFinishes(finish);
		setNumberPerUnit(numberPerUnit);
		setPricePerUnit(unitPrice);
	}

	private void setMaterial(String material) throws IllegalFastener{      //set the material attribute which must equal Brass, Stainless Steel, or Steel.
		
		if ((material == null) || 
		   ((material.equalsIgnoreCase("Brass") == false) && (material.equalsIgnoreCase("Stainless Steel") == false) 
		    && (material.equalsIgnoreCase("Steel") == false))) {
				throw new IllegalFastener("Your input for the material field is not correct.");	
		}
		this.material = material;
	}
	
	private void setFinishes(String finish) throws IllegalFastener{      //set the finish attribute which must equal Chrome, Hot Dipped Galvanized, Plain, Yellow Zinc, Zinc.
		
		if (finish == null) {
			throw new IllegalFastener("Your input for the finish field is not correct.");
		} else if ((material.equalsIgnoreCase("Steel") == true) && 
				((finish.equalsIgnoreCase("Chrome") == true) || (finish.equalsIgnoreCase("Hot Dipped Galvanized") == true) 
				|| (finish.equalsIgnoreCase("Yellow Zinc") == true) || (finish.equalsIgnoreCase("Zinc") == true)
				|| (finish.equalsIgnoreCase("Black Phosphate") == true) || (finish.equalsIgnoreCase("ACQ 1000 Hour") == true)
				|| (finish.equalsIgnoreCase("Lubricated") == true) || (finish.equalsIgnoreCase("Bright") == true))) {
			this.finish = finish;
		} else if (finish.equalsIgnoreCase("Plain") == true) {     //assign value plain to any attribute
			this.finish = finish;
		} else {
			throw new IllegalFastener("Your input for the finish field is not correct.");   //throw exception if all else fails
		}
	}
	
	private void setNumberPerUnit (int numberPerUnit) throws IllegalFastener {    //Number per Unit" must be at least 1, but could be as high as 10,000. 
		  //This number will always be one or if higher, evenly divisible by 5.	
		if ((numberPerUnit >= 1) && (numberPerUnit <= 10000)) {
			if ((numberPerUnit == 1) || ((numberPerUnit % 5) == 0)) {
				this.numberPerUnit = numberPerUnit;
			} else {
				throw new IllegalFastener("Your input for the Number Per Unit field is not correct."); 
			}
		} else {
			throw new IllegalFastener("Your input for the Number Per Unit field is not correct."); 
		}
	}

	private void setPricePerUnit (double unitPrice) throws IllegalFastener{      //The Unit Price, in dollars, must be greater than zero and is the price per unit.

		if (unitPrice > 0) {
			this.unitPrice = unitPrice;
		} else {
			throw new IllegalFastener("Your input for the Unit Price field is not correct."); 
		}
	}
	
    public double getOrderCost (int unitsNumber) {     //accepts the number of units of any fastener and returns the total cost of such an order
	    
    	if (unitsNumber <= 0) {
    		return 0;
    	} else {
        	return unitsNumber * unitPrice;
    	}
    }
    
    public String toString() {     //create a function that converts the object to a string
    	
		String out = material + ", with a " + finish + " finish. ";
		out += numberPerUnit + " in a unit, $" + unitPrice + " per unit.";
		return out;
	}
	
}
