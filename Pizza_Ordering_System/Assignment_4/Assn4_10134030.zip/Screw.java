
//The Screws class is a child of Fastenal and parent of all screws
public abstract class Screw extends Bolt{
 
	private static final long serialVersionUID = 5312860066160316642L;
	private String head;
	private String drive;
    
	//constructor method to set values
	public Screw (String material, String finish, double unitPrice, int numberPerUnit, String thread, double length, String head, String drive) throws IllegalFastener{
		super(material, finish, unitPrice, numberPerUnit, thread, length);
		setHead(head);
		setDrive(drive);
		checkFinish(finish);    //we need to check finish again because some finishes approved at the highest level cannot be given to screws
	}

    //ensure the drive is correctly inputed: Drive for all Screws: 6-Lobe, Philips, Slotted, Square
	private void setDrive(String drive) throws IllegalFastener{
		
		if (drive == null) {  //check for null and the right classification for drive
			throw new IllegalFastener("Your input for the drive class is incorrect.");
		} else if ((drive.equalsIgnoreCase("6-Lobe") == true) || (drive.equalsIgnoreCase("Philips") == true) 
				|| (drive.equalsIgnoreCase("Slotted") == true) || (drive.equalsIgnoreCase("Square") == true)) {
			this.drive = drive;
		} else {
			throw new IllegalFastener("Your input for the drive class is incorrect.");
		}
	}
	
    //ensure the head is correctly inputed: Head for all Screws: Bugle, Flat, Oval, Pan, Round.
	private void setHead(String head) throws IllegalFastener{
		
		if (head == null) {     //check for null and the right classification for head
			throw new IllegalFastener("Your input for the head class is incorrect.");
		} else if ((head.equalsIgnoreCase("Bugle") == true) || (head.equalsIgnoreCase("Flat") == true) 
				|| (head.equalsIgnoreCase("Oval") == true) || (head.equalsIgnoreCase("Pan") == true) 
				|| (head.equalsIgnoreCase("Round") == true)) {
			this.head = head;
		} else {
			throw new IllegalFastener("Your input for the head class is incorrect.");
		}
	}
	//cannot be Bright
	private void checkFinish (String finish) throws IllegalFastener{
		
		if (finish.equalsIgnoreCase("Bright") == true) {
			throw new IllegalFastener("Your input for the finish class is incorrect, cannot be Bright.");
		}
	}
	
	public String toString() {
		return head + " head, " + drive + " drive, " + super.toString();
	}
    
}
