//Parent class for all bolts. Specific bolts created will extend the bolt class and this class is a child of the fastenal class
public abstract class Bolt extends InnerThreaded{
    
	private static final long serialVersionUID = 4719642611363453542L;
	private double length;

	public Bolt (String material, String finish, double unitPrice, int numberPerUnit, String thread, double length)  throws IllegalFastener{       //create the parameters
		super(material, finish, unitPrice, numberPerUnit, thread);
		setLength(length);
	}

	//Lengths for Bolts and Screws must equal one of these value 1/2" to 6" in units of 1/4", 6" to 11" in units of 1/2
	private void setLength (double length) throws IllegalFastener{      
		
		if ((length >= 0.5) && (length <= 6.0)) {   //control structure that analyzes double parameter
			if ((length % 0.25) == 0) {
				this.length = length;
			} else {
				throw new IllegalFastener("Your input for the length field is not correct.");
			}
		} else if ((length >= 6.0) && (length <= 11.0)) {
			if ((length % 0.5) == 0) {
				this.length = length;
			} else {
				throw new IllegalFastener("Your input for the length field is not correct.");
			}
		} else if ((length >= 11) && (length <=20)) {
			if ((length % 1) == 0) {
				this.length = length;
			} else {
				throw new IllegalFastener("Your input for the length field is not correct.");
			}
		} else {
			throw new IllegalFastener("Your input for the length field is not correct.");
		}
	}

	public String toString() {
		return length + "\" long, " + super.toString();
	}
}
