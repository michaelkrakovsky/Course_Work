//Direct child of the screws class, add an additional point feature
public class WoodScrew extends Screw{

	private static final long serialVersionUID = 2179852128888486868L;
	private String point;
	
	public WoodScrew (double length, String thread, String material, String finish, String head, String drive, String point, double unitPrice, int numberPerUnit) throws IllegalFastener{
		super(material, finish, unitPrice, numberPerUnit, thread, length, head, drive); 
		setPoint(point);
	}
	
	//Point for Wood Screws: Double Cut, Sharp, Type 17
	private void setPoint (String screwPoint) throws IllegalFastener{
		
		if (screwPoint == null) {
			throw new IllegalFastener("Your input for the point parameter is incorrect");
		} else if ((screwPoint.equalsIgnoreCase("Double Cut") == true) 
				|| (screwPoint.equalsIgnoreCase("Sharp") == true) 
				|| (screwPoint.equalsIgnoreCase("Type 17") == true)) {
			point = screwPoint;
		} else {
			throw new IllegalFastener("Your input for the point parameter is incorrect");
		}
	}
	
	public String toString() {
		return "Wood Screw, " + point + " point, " + super.toString();
	}
}
