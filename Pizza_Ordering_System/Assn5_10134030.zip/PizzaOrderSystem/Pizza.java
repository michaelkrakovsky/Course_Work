package PizzaOrderSystem;

import java.io.Serializable;     //Make the object Serializable to ensure
/**
 * A class to store pizza information.
 * <p>
 * The size, the amount of cheese, the amount of mushrooms, and the amount of pepperoni.
 * There are exceptions to these parameters; however, they are located within the IllegalPizza class.
 * </p>
 * @author Michael Krakovsky
 *@version 1.0 
 */

public class Pizza implements Serializable {

	private static final long serialVersionUID = -8228641906801954735L;
	private String size;       //Since they are private, they are immutable once declared 
	private String cheese;  
	private String mushrooms;  
	private String pepperoni;   
	
	/**
	 * Full parameter constructor
	 * @param size The size of the pizza defined as "small", "medium", or "large"
	 * @param cheese The amount of cheese defined as "single", "double", or "triple"
	 * @param mushrooms The amount of mushrooms defined as "single", "double", or "none"
	 * @param pepperoni The amount of pepperoni defined as "single", "double", or "none"
	 * @throws IllegalPizza if information is incorrectly inputed
	 */
	
	public Pizza () {    //Default constructor that creates a small pizza with single cheese and single pepperoni without mushrooms
		size = "small";
		cheese = "single"; 
		mushrooms = "none";
		pepperoni = "single";
	}
	
	public Pizza (String size, String cheese, String mushrooms, String pepperoni) throws IllegalPizza {     //sets variables when four parameters are passed through
		setSize(size);
		setCheese(cheese);
		setPepperoni(pepperoni);
		setMushrooms(mushrooms);
	}
	/**
	 * Method that sets the size or throws an exception.
	 * @param pizzaSize The pizza size entered by the user.
	 * @throws IllegalPizza if the pizza size doesn't equal "small", "medium", or "large" 
	 */
	private void setSize (String pizzaSize) throws IllegalPizza {      
		
		if (pizzaSize == null) {
			throw new IllegalPizza("The data entry cannot be null.");
		}
		if ((pizzaSize.toLowerCase().equals("small") == false) && (pizzaSize.toLowerCase().equals("medium") == false) && (pizzaSize.toLowerCase().equals("large") == false)) {
		   throw new IllegalPizza("Your entry is not a valid entry for the size parameter."); 
		}	
		size = pizzaSize.toLowerCase();
	}
	/**
	 * Method that sets the cheese amount or throws an exception.
	 * @param cheeseAmount The cheese amount entered by the user.
	 * @throws IllegalPizza if the cheese amount doesn't equal "single", "double", or "triple" 
	 */
	private void setCheese (String cheeseAmount) throws IllegalPizza{      //Method that sets the cheese or throws exception
	    
		if (cheeseAmount == null) {
			throw new IllegalPizza("The data entry cannot be null.");
		}
		if ((cheeseAmount.toLowerCase().equals("single") == false) && (cheeseAmount.toLowerCase().equals("double") == false) && (cheeseAmount.toLowerCase().equals("triple") == false)) {
			   throw new IllegalPizza("Your entry is not a valid entry for the cheese parameter."); 
		}
		cheese = cheeseAmount.toLowerCase();
	}
	/**
	 * Method that sets the pepperoni amount or throws an exception.
	 * @param pepperoniAmount The pepperoni amount entered by the user.
	 * @throws IllegalPizza if the pepperoniAmount amount doesn't equal "single", "double", or "none". 
	 */
	private void setPepperoni (String pepperoniAmount) throws IllegalPizza {      //Method that sets the Pepperoni
	    
		if (pepperoniAmount == null) {
			throw new IllegalPizza("The data entry cannot be null.");
		}
		if ((pepperoniAmount.toLowerCase().equals("single") == false) && (pepperoniAmount.toLowerCase().equals("double") == false) && (pepperoniAmount.toLowerCase().equals("none") == false)) {
			   throw new IllegalPizza("Your entry is not a valid entry for the pepperoni parameter."); 
		}
		pepperoni = pepperoniAmount.toLowerCase(); 
	}
	/**
	 * Method that sets the mushrooms amount or throws an exception.
	 * @param mushroomsAmount The mushrooms amount entered by the user.
	 * @throws IllegalPizza if the mushroomsAmount amount doesn't equal "single", "double", or "none". 
	 * @throws IllegalPizza if a pizza object is created with mushrooms without pepperoni 
	 */
	private void setMushrooms (String mushroomsAmount) throws IllegalPizza {      //Method that sets the Mushrooms
	    
		if (mushroomsAmount == null) {
			throw new IllegalPizza("The data entry cannot be null.");
		}
		if ((mushroomsAmount.toLowerCase().equals("single") == false) && (mushroomsAmount.toLowerCase().equals("double") == false) && (mushroomsAmount.toLowerCase().equals("none") == false)) {
			   throw new IllegalPizza("Your entry is not a valid entry for the mushrooms parameter."); 
		}
		if ((pepperoni.toLowerCase().equals("none") == true) && (mushroomsAmount.toLowerCase().equals("none") == false)) {
			throw new IllegalPizza("You cannot have mushrooms without pepperoni.");
	    }
		mushrooms = mushroomsAmount.toLowerCase();
	}
    /**
     * Method that adds additional costs based on topics
     * Each additional topping after the base price is equal to 1.50
     * @return additionalCost is the additional cost after toppings 
     */
	private double costAfterToppings () {
		
		double additionalCost = 0.00d;       
		
		if (mushrooms.equals("single") == true) {     //add 1.5 dollars if an additional costs is added
			additionalCost += 1.50d;
		} else if (mushrooms.equals("double") == true) {
			additionalCost += 3.00d;
		}
		if (pepperoni.equals("single") == true) {
			additionalCost += 1.50d;
		} else if (pepperoni.equals("double") == true) {
			additionalCost += 3.00d;
		}
		if (cheese.equals("double") == true) {
			additionalCost += 1.50d;
		} else if (cheese.equals("triple") == true) {
			additionalCost += 3.00d;
		}
		
		return additionalCost;
	}
	/**
     * Method that returns the cost of the pizza
     * A small cheese pizza with single cheese only is $7.00, a medium with cheese 
     * only is $9.00 and a large with cheese only is $11.00. 
     * Each additional topping costs $1.50 each.
     * @return cost Total value of the pizza
     */
	public double getCost () {
		double pizzaCost = 0.00d;  
		double additionalCost = costAfterToppings();
		
		if (size.equals("small") == true) {
			pizzaCost = 7.00d;         //currently assume that the pizza begins with a small cheese 
			pizzaCost = pizzaCost + additionalCost;        //add the additional cost
		} else if (size.equals("medium") == true) {
		    pizzaCost = 9.00d; 
		    pizzaCost = pizzaCost + additionalCost;
		} else {
		    pizzaCost = 11.00d; 
		    pizzaCost = pizzaCost + additionalCost;
		}
		return pizzaCost;
	}
    /**
     * Method that returns a description of the pizza
     * @return A String that represents the contents of the object
     */
	//Overrides the current toString method of the Object class
	@Override
	public String toString () {
		
		String describeObject;
		double cost = getCost();
		
		describeObject = (size + " pizza, ");
		describeObject += (cheese + " cheese, ");
		if (mushrooms.equals("none") == true) {   //modify String if there are no mushrooms for proper English
			describeObject += "no mushrooms, ";
		} else {
			describeObject += (mushrooms + " mushrooms, ");
		}
		if (pepperoni.equals("none") == true) {
			describeObject += "no pepperoni. ";
		} else {
			describeObject += (pepperoni + " pepperoni. ");
		} 
		return describeObject;
	}
    /**
     * Tests whether two objects equal each other
     * @return <code>true</code> every attribute matches each other
     * @param otherObject The other pizza object
     */
	 //Overrides the current equals boolean function
	 @Override
	public boolean equals (Object comparisonObject) {
		 
		 if (comparisonObject instanceof Pizza) {
			 Pizza pizzaObjectTwo = (Pizza)comparisonObject;
		     if ((pizzaObjectTwo.size.equals(size) == false) ||
		    	(pizzaObjectTwo.cheese.equals(cheese) == false) ||
		    	(pizzaObjectTwo.mushrooms.equals(mushrooms) == false) ||
		    	(pizzaObjectTwo.pepperoni.equals(pepperoni) == false)) {
		    	    return false;
		     }
		 }
		 return true;
	 }
    /**
     * Create a clone class that returns the same object
     * @return A copy of the current object
     */
	 //Overrides the current clone method
	 @Override
	 public Pizza clone () {
		 
		 Pizza copy = null;
		 
	     try {
	    	 copy = new Pizza(size, cheese, mushrooms, pepperoni);
	     } catch (IllegalPizza e) {
	    	 return null;        //The code will never reach here
	     }
	     return copy;
	 }
}
