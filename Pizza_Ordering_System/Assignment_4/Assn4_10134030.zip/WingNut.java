//extends the threaded fastenal class but doesn't have a length
public class WingNut extends InnerThreaded{
    
	private static final long serialVersionUID = 3744863551235647028L;

	public WingNut (String thread, String material, String finish, double unitPrice, int numberPerUnit) throws IllegalFastener{
		super(material, finish, unitPrice, numberPerUnit, thread);
		checkFinish(finish);
	}
	
	//Only for steel screws: Black Phosphate, ACQ 1000 Hour, Lubricated. Only for steel nails: Bright
	private void checkFinish (String finish) throws IllegalFastener {
		
		if ((finish.equalsIgnoreCase("Bright") == true) || (finish.equalsIgnoreCase("Black Phosphate") == true)
			|| (finish.equalsIgnoreCase("ACQ 1000 Hour") == true) || (finish.equalsIgnoreCase("Lubricated") == true)) {
				throw new IllegalFastener("Your input for the finish class is incorrect.");
		}
	}
	
	public String toString() {
		return "Wing Nut, " + super.toString();
	}
}
